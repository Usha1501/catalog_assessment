package com.example;

import java.io.FileReader;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;

public class Main{

    
    public static List<Point> parseJson(String filePath) {
        List<Point> points = new ArrayList<>();
        
        try (FileReader reader = new FileReader(filePath)) {
            JsonObject jsonObject = JsonParser.parseReader(reader).getAsJsonObject();
            
            // Extract number of roots (n) and minimum number of roots (k)
            int n = jsonObject.get("keys").getAsJsonObject().get("n").getAsInt();
            int k = jsonObject.get("keys").getAsJsonObject().get("k").getAsInt();
            
            // Iterate through each root point in the JSON file
            for (String key : jsonObject.keySet()) {
                if (key.equals("keys")) continue;
                
                JsonObject rootObj = jsonObject.getAsJsonObject(key);
                int x = Integer.parseInt(key);
                
                String base = rootObj.get("base").getAsString();
                String encodedValue = rootObj.get("value").getAsString();
                
                // Decode y value based on specified base
                BigInteger y = new BigInteger(encodedValue, Integer.parseInt(base));
                
                points.add(new Point(x, y));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return points;
    }

    // Class to store a point (x, y)
    static class Point {
        int x;
        BigInteger y;

        Point(int x, BigInteger y) {
            this.x = x;
            this.y = y;
        }
    }

    // Perform Lagrange interpolation to find the polynomial constant term (c)
    public static BigInteger lagrangeInterpolation(List<Point> points, int k) {
        BigInteger secret = BigInteger.ZERO;
        
        for (int i = 0; i < k; i++) {
            BigInteger term = points.get(i).y;
            
            for (int j = 0; j < k; j++) {
                if (i != j) {
                    BigInteger numerator = BigInteger.valueOf(-points.get(j).x);
                    BigInteger denominator = BigInteger.valueOf(points.get(i).x - points.get(j).x);
                    term = term.multiply(numerator).divide(denominator);
                }
            }
            
            secret = secret.add(term);
        }
        
        return secret;
    }

    public static void main(String[] args) {
        String filePath = "/Users/giridharnelluri/DAA1/exam_catalog/demo/src/test/java/com/test.json";  // Path to your JSON file
        
        // Parse roots from JSON file
        List<Point> points = parseJson(filePath);
        
        // Assuming the value of k (minimum number of roots to solve for coefficients)
        int k = points.size() - 1;

        // Solve for the constant term (c) of the polynomial
        BigInteger secret = lagrangeInterpolation(points, k);
        
        System.out.println("Secret: " + secret);
    }
}

